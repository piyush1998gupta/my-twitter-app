// const mangoose=require("mongoose");
const User = require("../models/users");

const Tweet = require("../models/tweets")


let information = async function(id){
    
    let data = await User.findById(id).populate("tweets");
   
   
   

   
    
    

    
    return data;
}

let alltweets_relatedtoUser = async function(id){
    let data = await User.find({_id:id},"following")
    
    data[0].following.unshift(id)
    data=data[0].following;
    let tweets = await Tweet.find({userId : {
        $in : data
    }}).populate("userId");
    return tweets;
}

let alltweets = async function(){
    let data = await Tweet.find({}).populate("userId");
    return data;
}
module.exports={
    information,alltweets,alltweets_relatedtoUser
}
