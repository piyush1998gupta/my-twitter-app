const express = require("express");
const app = express();
const hbs = require("hbs");
const route = require("./routes/route");
const login = require("./routes/login");
const passport = require("./passport");
const session = require('express-session');
const db = require("./db/dbserver");
const user=require("./models/users");
// const query = require("./query");

const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true }));

app.use(session({
    secret:'abcdefghijklmmmmmmmoooopasoakjscacbjka',
    resave:false,
    saveUninitialized:true
}))
app.use(passport.initialize())
app.use(passport.session())

app.use(express.static(__dirname+'/static'));
app.set('view engine', 'hbs');
app.set('view options');
app.set('isCached','false');
hbs.registerPartials(__dirname + '/views/partials', function (err) {});



app.use("/",route);
app.use("/login",login);
app.use("/signup",require("./routes/signup"));
app.use("/home",require("./routes/home"));
app.use("/profile",require("./routes/profile"));
app.use("/explore",require("./routes/explore"));
app.use("/tweet",require("./routes/tweet"));
app.use("/comment",require("./routes/comment"));












app.listen(8080,()=>{
    console.log("Server started at http://localhost:8080");
})