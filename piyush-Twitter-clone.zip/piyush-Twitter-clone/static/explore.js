$(()=>{
    console.log("explore - tab")
    // $.get("/explore/all-tweets",(data)=>{
    //     console.log(data);
    //     for(let i=0;i<data.length;i++){
    //         addtweet(data[i]);
    //     }
    // })
    // function addtweet(data){
    //     let date = new Date(data.createdDate);
    //     console.log(date);
    //     let datetext = `${date.getDate()}/${date.getMonth()+1}/${date.getFullYear()}  ${date.getHours()}:${date.getMinutes()}`
    //     $("#all-tweets").prepend(
    //         `<div  class="d-flex justify-content-center w-500">
    //         <div class="card " id="${data._id}" >
    //         <div class="card-header" id="${data.userId._id}">
    //           ${data.userId.full_name}( ${data.userId.email})
    //         </div>
    //         <div class="card-body">
    //           <h5 class="card-title"> ${data.content}</h5>
    //           <p class="card-text">#${data.topic}</p>
    //           <a href="#" class="btn btn-primary">${data.likes.length} likes</a>
    //           <a href="#" class="btn btn-primary">${data.comments.length} comments</a>

    //         </div>
    //         <div class="card-footer text-muted">
    //           Posted on ${datetext}
    //         </div>
    //       </div>
    //       </div>
    //       <br>
    //       `
    //     )
    // }
})