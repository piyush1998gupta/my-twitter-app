const mongoose = require("mongoose");
mongoose.connect("mongodb+srv://piyush_database:39e1pKI5tkVRAyWv@cluster0.hh9f9.mongodb.net/twitter?retryWrites=true&w=majority")
// mongoose.connect("mongodb://localhost:27017/twitter");
const db = mongoose.connection
db.on('error', (err)=>{
    console.error(err)
})