// let followUnfollow;
// $(()=>{
//     let profile_id = $(".current-user")[0].id;
//     $.post("/check-follower/"+profile_id,function (data){
//         if(data){
//          $("#btn-follow-unfollow").text("Unfollow");
//         }else{
//          $("#btn-follow-unfollow").text("follow");
//         }
//      })
//   followUnfollow =  function (){
        
//         let value= $("#btn-follow-unfollow").text();
//         console.log(value);
//         if(value=="follow"){
//             console.log("shs");
//             $.post("/add-following/"+profile_id,function(data){

//             })

//         }else{

//         }
       
//     }

//     // followUnfollow();
//     $("#btn-follow-unfollow").click (function(){
//         followUnfollow();
        
//     })
// })