
const route = require("express").Router();
const userQuery= require("../Controller/userQuery");
const Comment = require("../models/comments");
const Tweet = require("../models/tweets");
const User = require("../models/users");


route.get("/:id/like",async (req,res)=>{
    if(req.user){
        // console.log(req.user._id);
        await userQuery.addLike(req.params.id,req.user._id);
        let requrl =req.headers.referer;
        

        requrl=requrl.split("localhost:")[1].substr(4);
        return res.redirect(requrl);
    }else{
        return res.redirect("/");

    }
})


route.get("/:id/unlike",async (req,res)=>{
    if(req.user){
        // console.log(req.user._id);
        
        await userQuery.removeLike(req.params.id,req.user._id);
        let requrl =req.headers.referer;
        

        requrl=requrl.split("localhost:")[1].substr(4);
        return res.redirect(requrl);
    }else{
        return res.redirect("/");

    }
})

route.get("/:id/tweet-details",async (req,res)=>{
    if(req.user){
        // console.log("inside get");
           let data= await userQuery.tweetInfo(req.params.id);
           res.send(data);
    }else{
        return res.redirect("/");

    }
})

route.get("/:id",async (req,res)=>{
    // console.log(req.headers.referer);
        if(req.user){
            let tweet= await userQuery.tweetInfo(req.params.id);
            // console.log(tweet);
            if(await userQuery.checkLike1(tweet,req.user._id)){
                    tweet.likeTweet=true;
                    // console.log(true);
                    
            }else{
                tweet.likeTweet=false;
                // console.log(false);
            }
            // console.log(...tweet);
                res.render("tweet",{
                        tweet,
                        userId:req.user._id,
                        name:req.user.full_name
                })
        }else{
            return res.redirect("/");

        }
})

route.post("/:id/add-comment",async (req,res)=>{

    if(req.user){
            let tweetData={
                content: req.body.content,
                userId:req.user._id,

            }
           let commentId= await Comment.create(tweetData);
           let userdata = await User.findOne({_id:req.user._id});
           userdata.comments.unshift(commentId._id);
           let tweetdata = await Tweet.findOne({_id:req.params.id});
           tweetdata.comments.unshift(commentId._id);
           await userdata.save();
           await tweetdata.save();

            res.redirect("/tweet/"+req.params.id);
    }else{
        return res.redirect("/");
    }
})


module.exports = route