const route= require("express").Router();
const query=require("../Controller/query");
const userQuery=require("../Controller/userQuery");

route.get("/",async (req,res)=>{
    
    
    if(req.user){
        let details = await query.information(req.user._id);
        await userQuery.beforeTweets(details.tweets,req.user._id);
    return res.render("my-profile",{details,
            loginUser : req.user._id,
            
            name:req.user.full_name
        });
    }else{
        return res.redirect("/login");
    }
})


route.get("/:id",async (req,res)=>{
    // console.log("inside this");
    // console.log(req.params);

    if(req.user){
        // console.log(req.params.id);
        // console.log(req.user._id);

        if(req.params.id==req.user._id){
            return res.redirect("/profile");
        }else{
        

        let details = await query.information(req.params.id);
            let follows = await userQuery.checkFollower(req.user._id,req.params.id);
            if(follows){
                details.follows=true;
            }
            await userQuery.beforeTweets(details.tweets,req.user._id);
        // console.log(req.user._id);
        
        return res.render("general-profile",{details,
            loginUser : req.user._id,
            
            name:req.user.full_name
        });
    }
    }else{
       return res.redirect("/login");
    }
})
module.exports= route;