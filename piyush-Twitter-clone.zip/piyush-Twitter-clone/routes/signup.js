
const route = require("express").Router();
const addQuery = require("../Controller/add");
const User = require("../models/users");
const bcrypt = require('bcrypt');
const saltRounds = 10;

route.get("/",(req,res)=>{
    if(req.user){
        return res.redirect("/");

    }else{
        
        return res.render("signup");
    }
})



route.post("/",async (req,res)=>{
    let userData = {
        info:req.body.info,
        username:req.body.username,
        email:req.body.email,
        password:req.body.password,
        full_name:req.body.full_name
    }
    // console.log(userData);

    
   let user = await  User.findOne({ username: userData.username });
   if(user){
    userData.alert = "Username already exist.";
    return res.render("signup",userData);
   } 
   user = await  User.findOne({ email: userData.email});
   if(user){
       if(user.password){
           userData.alert = "Email already exist";
          return  res.render("signup",userData);
       } 
       userData.password = await bcrypt.hash(req.body.password, saltRounds);
        user.password = userData.password;
        user.username = userData.username;
        user.info = userData.info;
        user.save();
        return res.redirect("/login");
   }else{
    userData.password = await bcrypt.hash(req.body.password, saltRounds);
    User.create(userData, (err,user)=>{
        
        if(err) return res.send(err)
        return res.redirect('/login');
    })
}
    
})

module.exports = route