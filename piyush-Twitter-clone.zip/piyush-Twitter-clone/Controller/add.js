const User = require("../models/users");
const Tweet = require("../models/tweets");

let AddInTheDatabase = async function(userData){
    // console.log("inside database");
    await User.create(userData, (err,user)=>{
        console.log(err);
        if(err) return err
        return userData;
    })
    // console.log("inside database end");
} 


let AddTweet = async function(data,userId){
       let tweet = await Tweet.create({
            userId:userId,
            content:data.content,
            topic:data.topic
        })
       
        let masterdata = await User.findById(userId);
        
        
            
           await masterdata.tweets.unshift(tweet._id);
           await masterdata.save();
       


        

}


module.exports={AddInTheDatabase,AddTweet};