const route = require("express").Router();
const commentQuery= require("../Controller/comment");
const Tweet = require("../models/tweets");
const User = require("../models/users");
const Comment = require("../models/comments");


route.get("/:id/like",async (req,res)=>{
    if(req.user){
        // console.log(req.user._id);
        await commentQuery.addLike(req.params.id,req.user._id);
        let requrl =req.headers.referer;
        

        requrl=requrl.split("localhost:")[1].substr(4);
        return res.redirect(requrl);
    }else{
        return res.redirect("/");

    }
})


route.get("/:id/unlike",async (req,res)=>{
    if(req.user){
        // console.log(req.user._id);
        
        await commentQuery.removeLike(req.params.id,req.user._id);
        let requrl =req.headers.referer;
        

        requrl=requrl.split("localhost:")[1].substr(4);
        return res.redirect(requrl);
    }else{
        return res.redirect("/");

    }
})

route.get("/:id",async (req,res)=>{
    // console.log(req.headers.referer);
        if(req.user){
            let comment= await commentQuery.commentInfo(req.params.id);
            // console.log(tweet);
            if(await commentQuery.checkLike1(comment,req.user._id)){
                comment.likeTweet=true;
                    // console.log(true);
                    
            }else{
                comment.likeTweet=false;
                // console.log(false);
            }
            // console.log(...tweet);
                res.render("comment",{
                        comment,
                        userId:req.user._id,
                        name:req.user.full_name
                })
        }else{
            return res.redirect("/");

        }
})


route.get("/:id/comment-details",async (req,res)=>{
    if(req.user){
        // console.log("inside get");
           let data= await commentQuery.commentInfo(req.params.id);
           res.send(data);
    }else{
        return res.redirect("/");

    }
})

route.post("/:id/add-reply",async (req,res)=>{

    if(req.user){
            let CommentData={
                content: req.body.content,
                userId:req.user._id,

            }
           let replydata= await Comment.create(CommentData);
           let userdata = await User.findOne({_id:req.user._id});
           userdata.comments.unshift(replydata._id);
           let commentdata = await Comment.findOne({_id:req.params.id});
           commentdata.comments.unshift(replydata._id);
           await userdata.save();
           await commentdata.save();

            res.redirect("/comment/"+req.params.id);
    }else{
        return res.redirect("/");

    }
})


module.exports = route;