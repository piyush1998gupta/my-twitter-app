$(()=>{
    // $("#new-tweet").submit((ev)=>{
    //     ev.preventDefault();
    //     let tweetData = $('form#new-tweet').serialize();
    //   $.post("/home/new-tweet",tweetData,(data)=>{
    //         console.log(data);
    //   })
    //   $("#new-tweet").trigger("reset");
    // })
})