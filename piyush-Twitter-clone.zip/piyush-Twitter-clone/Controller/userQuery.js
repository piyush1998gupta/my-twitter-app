const User = require("../models/users");

const Tweet = require("../models/tweets");


async function checkFollower(curr_user,other_user){
    let result = await User.findOne({_id:curr_user},"following");  
    let followingList = result.following;

    let idx = followingList.indexOf(other_user);


    if(idx==-1){
        return false;
    }else{
        return true;
    }
}


async function addFollowing(curr_user,other_user){
    let result = await User.findOne({_id:curr_user},"following");  
   
  
   
        await result.following.unshift(other_user);
        let otheruser = await User.findOne({_id:other_user},"follower");
        await otheruser.follower.unshift(curr_user);
        await result.save();
        await otheruser.save();

    
}
async function removeFollowing(curr_user,other_user){
    let result = await User.findOne({_id:curr_user},"following");  

   
        let idx = result.following.indexOf(other_user);
        if(idx>-1){
            result.following.splice(idx,1);
        }
        let otheruser = await User.findOne({_id:other_user},"follower");
        let idx1 = otheruser.follower.indexOf(curr_user);
        if(idx>-1){
            otheruser.follower.splice(idx1,1);
        }
        await result.save();
        await otheruser.save();

    
}
async function getFollowing(id){
    let data = await User.findOne({_id:id}).populate("following");
    
    return data;
}
async function getFollower(id){
    
    let data = await User.findOne({_id:id}).populate("follower");
    
    return data;
}
function checkLike(tweet,user){
    // console.log(tweet);
    
        return tweet.likes.indexOf(user)!=-1;
}
async function checkLike1(tweet,user){
    // console.log(tweet);
    let data = await Tweet.findOne(tweet._id);
    // console.log(data);

    // console.log(data.likes.indexOf(user));
        return data.likes.indexOf(user)!=-1;
}

function Like(tweet,user){
    let idx= tweet.likes.indexOf(user);
    if(idx==-1){
        tweet.likes.unshift(user);
    }
}
function unlike(tweet,user){
    let idx= tweet.likes.indexOf(user);
    if(idx>-1){
        tweet.likes.splice(idx,1);
    }
}

async function addLike(tweetid,user){
        let tweet = await Tweet.findOne({_id:tweetid});
            Like(tweet,user);
            await tweet.save();
}

async function removeLike(tweetid,user){
    let tweet = await Tweet.findOne({_id:tweetid});
        unlike(tweet,user);
        await tweet.save();
}

function beforeTweets(tweets,user){
    for(let i=0;i<tweets.length;i++){
        if(checkLike(tweets[i],user)){
            tweets[i].likeTweet=true;
        }else{
            
            tweets[i].likeTweet=false;
        }
        
    }
    // console.log(tweets[0].toJSON());
   
}


async function tweetInfo(tweetid){
        let tweet = await Tweet.findOne({_id:tweetid}).populate("likes").populate("userId").populate({path:"comments",
    populate: {
        path:"userId likes"
    }});
        return tweet;
}


module.exports = {
checkFollower,addFollowing,removeFollowing,getFollowing,getFollower,beforeTweets,addLike,removeLike,tweetInfo,checkLike1
}