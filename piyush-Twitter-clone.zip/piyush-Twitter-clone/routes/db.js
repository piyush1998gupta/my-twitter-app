const MongoClient = require('mongodb').MongoClient;
const uri = "mongodb+srv://piyush_database:39e1pKI5tkVRAyWv@cluster0.hh9f9.mongodb.net/twitter?retryWrites=true&w=majority";
const client = new MongoClient(uri, { useNewUrlParser: true });
client.connect(err => {
  const collection = client.db("twitter").collection("user");
  // perform actions on the collection object
  console.log(collection);
  client.close();
});