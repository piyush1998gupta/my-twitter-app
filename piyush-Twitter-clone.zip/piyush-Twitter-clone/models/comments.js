const mongoose = require("mongoose");

const CommentSchema =new mongoose.Schema({
    userId : {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    } ,
    createdDate: { 
        type: Date,
         default: Date.now 
        },
        content:{
            type:String,
            required:true
        },
        likes:[{
            type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
        }],
        comments:[{
            type: mongoose.Schema.Types.ObjectId,
        ref: 'Comment'
        }]


})
const Comment = mongoose.model('Comment',CommentSchema)
module.exports = Comment