const route = require("express").Router();
const passport = require('passport')
const bcrypt = require('bcrypt');


route.get('/',(req,res)=>{
  // console.log(req);
  if(req.user){
     return  res.redirect('/profile')
  }else{

    return res.render('login')
  }
})


// Post '/'
route.post('/',passport.authenticate('local',{
  failureRedirect:'/login',
  successRedirect:'/profile'
}))

route.get('/facebook',passport.authenticate('facebook'));

route.get('/facebook/callback',passport.authenticate('facebook',
   { failureRedirect: '/login',
   successRedirect:'/profile' }),
 );




route.get('/twitter',passport.authenticate('twitter'));

route.get('/twitter/callback', passport.authenticate('twitter', { failureRedirect: '/login',
successRedirect:'/profile'
 }),
  function(req, res) {
    // Successful authentication, redirect home.
    console.log(req);
    console.log("hello ggf")
    res.redirect('/home');
  });


module.exports = route;