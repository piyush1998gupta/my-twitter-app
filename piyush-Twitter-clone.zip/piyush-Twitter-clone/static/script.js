let tweetLikes,addLikeUsers,addComment,addCommentBox ;
let currUser,checkelement ;
$(()=>{
    currUser=$("nav")[0].id;
    tweetLikes= function (tweetid) {
        $.get("/tweet/"+tweetid+"/tweet-details",(data)=>{
            // console.log(data);
            

          let text=  addLikeUsers(data) +" tweet.";
          $("#likes").html(text);
            addComment(data);
        })
    }
    
    tweetLikes($(".tweet-id")[0].id);
    addLikeUsers=function(data){
        // console.log(data);
      
        let text = "";
        if(data.likes.length==0){
           return "No One likes this ";
            
        }
        for(let i=0;i<data.likes.length;i++){
            if(currUser!=data.likes[i]._id){
                // console.log("if" +text);
            text+=`<a href='/profile/${data.likes[i]._id}'> ${data.likes[i].full_name}  ,</a>`
            }
            else{
                // console.log("else");
                // console.log(text);

                text=`<a href='/profile/${currUser}'>You ,</a>`+text;
            }

        }
        text+=` likes this `;
        // console.log(text);
        return text;
       
    }

    addComment = function (data) {
        $("#tweet-all-comment").html("");
            for(let i=0;i<data.comments.length;i++){
                addCommentBox(data.comments[i])
            }
    }


    addCommentBox=function (data){
        let text;
        // console.log(data.likes);
        
        if(checkelement(data.likes)){
            // console.log("true");
            text=`<a href="/comment/${data._id}/unlike" class="btn btn-danger font-weight-bold btn-sm">  unlike</a>`
        }else{
            // console.log("false");
            text=`<a href="/comment/${data._id}/like" class="btn btn-success font-weight-bold btn-sm">  like</a>`
        }
        $("#tweet-all-comment").append(`
        <div class="card" style="max-width: 35rem;">
        <a href="/profile/${data.userId._id}">
    <div class="card-header alert alert-info  font-weight-bold">
        ${data.userId.full_name} (${data.userId.email})   

  </div>
  </a>
  <a href="/comment/${data._id}" class="text-dark" style="text-decoration: none;">
  <div class="card-body" >
    <blockquote class="blockquote mb-0">
      <p>${data.content}</p>
      
     ${text} <a href="/comment/${data._id}"  class="btn btn-warning font-weight-bold btn-sm">${data.likes.length}  likes</a>
      <a href="/comment/${data._id}" class="btn btn-outline-info font-weight-bold btn-sm">${data.comments.length} replies</a>

      </blockquote>
      </div>
      </a>
      <div class="card-footer text-normal" >
      <footer class="blockquote-footer">Commented On:-<cite title="Source Title">${new Date(data.createdDate)}</cite></footer>
            </div>
      <div class="card-footer text-normal font-italic text-monospace" >
      ${addLikeUsers(data)} comment.
            </div>
  
</div>
<br>
        `)
    }

    checkelement=function(objarr){
            for(let i=0;i<objarr.length;i++){
                if(objarr[i]._id==currUser){
                    return true;
                }
            }
            return false;
    }

    

    
})