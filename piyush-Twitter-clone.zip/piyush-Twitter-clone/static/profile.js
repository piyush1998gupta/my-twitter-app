
$(()=>{
 
    


    function addtweet(data,user,email){
        let date = new Date(data.createdDate);
        console.log(date);
        let datetext = `${date.getDate()}/${date.getMonth()+1}/${date.getFullYear()}  ${date.getHours()}:${date.getMinutes()}`
        $("#all-tweets").prepend(
            `<div  class="d-flex justify-content-center w-500">
            <div class="card " id="${data._id}" >
            <div class="card-header">
              ${user}( ${email})
            </div>
            <div class="card-body">
              <h5 class="card-title"> ${data.content}</h5>
              <p class="card-text">#${data.topic}</p>
              <a href="#" class="btn btn-primary">${data.likes.length} likes</a>
              <a href="#" class="btn btn-primary">${data.comments.length} comments</a>

            </div>
            <div class="card-footer text-muted">
              Posted on ${datetext}
            </div>
          </div>
          </div>
          <br>
          `
        )
    }

    function addinformation(){
        let userid = $("nav")[0].id;
        $.get("/profile/information/"+userid,(data)=>{
            
            if(!data.username) data.username="";
            if(!data.info) data.info="";
            $("#main-profile").append(
                `<div class="card">
                <h5 class="card-header">Name of the User:-${data.full_name} (@ ${data.username}) </h5>
                <div class="card-body">
                  <h5 class="card-title">Email : - ${data.email} </h5>
                  <p class="card-text">description :- ${data.info}</p>
                  <a href="/home" class="btn btn-primary"> ${data.follower.length} Following</a>
                  <a href="#" class="btn btn-primary"> ${data.following.length} followers</a>
              
                </div>    `
            )
            for(let i=0;i<data.tweets.length;i++){
                console.log(data.tweets[i]);
                addtweet(data.tweets[i],data.full_name,data.email);
            }
        })
    }
    // addinformation();
})