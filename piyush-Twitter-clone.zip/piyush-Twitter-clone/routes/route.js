

const route = require("express").Router();
const userQuery= require("../Controller/userQuery");
const  User= require("../models/users")


route.get("/",(req,res)=>{
    if(req.user){
        return res.redirect("/home");
    }else{
    return res.redirect("/login");
    }
})


route.get('/logout', function(req, res){
   
    if(req.user){
    req.logout();
    }
return res.redirect('/');
  });


// route.post("/check-follower/:id",async (req,res)=>{
//     // console.log("iside post request");
//     if(req.user){
//     // console.log("isside post request if condition");

//         let data = await userQuery.checkFollower(req.user._id,req.params.id);
//         // console.log(data);
//         return res.send( data);
//     }else{
//         res.send(new Error(404));
//     }
// })
route.get("/add-following/:id",async (req,res)=>{
    console.log("inl")
    if(req.user){
        await userQuery.addFollowing(req.user._id,req.params.id);
        res.redirect("/profile/"+req.params.id);
    }else{
        return res.redirect("/");

    }
})

route.get("/remove-following/:id",async (req,res)=>{
    
    if(req.user){
        await userQuery.removeFollowing(req.user._id,req.params.id);
        res.redirect("/profile/"+req.params.id);
    }else{
        return res.redirect("/");

    }
})


route.get("/:id/followers",async (req,res)=>{
    if(req.user){
    let details = await userQuery.getFollower(req.params.id);
    
    return res.render("followers",{details,
        loginUser : req.user._id,
        
        name:req.user.full_name
    });
}else{
    return res.redirect("/");

 }
})

route.get("/:id/following",async (req,res)=>{
    if(req.user){
    let details = await userQuery.getFollowing(req.params.id);
    // console.log(details);
    return res.render("following",{details,
        loginUser : req.user._id,
        
        name:req.user.full_name
    });
}else{
   return res.send(new Error(404));
}
})

route.get("/all-users",async (req,res)=>{
    if(req.user){
   let details= await User.find({_id :{
    $ne: req.user._id
    }});

   return  res.render("users",{details,
        loginUser : req.user._id,
        
        name:req.user.full_name
    })
}else{
    res.redirect("/");
}
})


module.exports = route;