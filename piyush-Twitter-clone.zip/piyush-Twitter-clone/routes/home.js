const route= require("express").Router();
const query = require("../Controller/add");
const query1 = require("../Controller/query");
const Userquery = require("../Controller/userQuery");



route.get("/",async (req,res)=>{
  // console.log(req.headers.referer);
    
    if(req.user){
      
        let data = await query1.alltweets_relatedtoUser(req.user._id);
        data.reverse();
        // console.log(data);
        await Userquery.beforeTweets(data,req.user._id);
        return res.render("home",{tweets:data,
          userId:req.user._id,
          name:req.user.full_name
        });
        }else{
          return   res.redirect("/login");
        }
})


route.post("/new-tweet",async (req,res)=>{
  if(req.user){
    console.log("inside-tweet")
    await query.AddTweet(req.body,req.user._id);
    return res.redirect("/home");
  }
  else{
    return res.send(new Error(404));
  }
})



module.exports= route;