const passport = require("passport");
const FacebookStrategy = require("passport-facebook").Strategy;
const TwitterStrategy = require("passport-twitter").Strategy;
const LocalStrategy = require("passport-local").Strategy;
const User = require('./models/users')
const bcrypt = require('bcrypt');

passport.use(new LocalStrategy({
  usernameField:'username',
  passwordField:'password'
  
},  function(username, password, done) {
  
    User.findOne({ username: username }, async function (err, user) {
      // console.log(user);
      if (err) { return done(err); }
      if (!user) { return done(null, false); }
      let value = await bcrypt.compare(password, user.password);
      // console.log(value);
      if (!value) { return done(null, false); }
      // console.log("kkkkk");
      return done(null, user);
    });
  }
));







passport.use(new FacebookStrategy({
    clientID: '209979697452158',
    clientSecret: 'e6df4b6bb67372683b5ae46968f7e26d',
    callbackURL: "http://localhost:8080/login/facebook/callback",
    profileFields: ['id', 'displayName','email']
  },
  async function(accessToken, refreshToken, profile, cb) {
  //  console.log(accessToken);
  //  console.log(profile);
  //  console.log(profile.emails[0].value)
  //  console.log(profile.id)
  //  console.log(profile.displayName)


  let user = await User.findOne({
    email : profile.emails[0].value
  })
  // console.log(user);
  if(user) {
    if(!user.fbid) user.fbid = profile.id;
    await user.save();
    return cb(null,user)
  }
  user = await User.create({email :profile.emails[0].value ,fbid:profile.id,  full_name:profile.displayName})

   return cb(null,user)
  }
));


passport.use(new TwitterStrategy({
  consumerKey: "wdX98phCk7J606pU5cMrRbEw5",
  consumerSecret: 'ipGu0oD7viZsQsLDvIevWaqjENDFelbrc15p2ZuAiz3KV70vwm',
  callbackURL: "http://localhost:8080/login/twitter/callback",
  includeEmail: true
},
async function(token, tokenSecret, profile, cb) {
  // console.log(token);
  // console.log(profile);
  // console.log(profile.emails[0].value);
  let user = await User.findOne({
    email : profile.emails[0].value
  })

  if(user) {
    if(!user.twitterid) user.twitterid=profile.id;
    if(!user.username)  user.username=profile.username;
    await user.save();
    return cb(null,user);
  }
  user = await User.create({email :profile.emails[0].value ,twitterid:profile.id,  full_name:profile.displayName,username:profile.username});
  return cb(null,user);
}
));


passport.serializeUser(function(user, done) {
  // console.log("inside serializs");
  
  // console.log(user.id);

  done(null, user.id);
});




passport.deserializeUser(function(id, done) {
  // console.log("inside deserializs");
  // console.log(id);
  // console.log("hhe");
  User.findOne({_id:id},"email full_name", function(err, user) {
    // console.log(user);
    done(err, user);
  });
  // console.log(user);
  // done(null,user);
});

module.exports = passport