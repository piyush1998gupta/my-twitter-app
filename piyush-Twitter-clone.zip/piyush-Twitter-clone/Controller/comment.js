const Comment= require("../models/comments");
const User= require("../models/users");
const Tweet= require("../models/tweets");



function Like(comment,user){
    let idx= comment.likes.indexOf(user);
    if(idx==-1){
        comment.likes.unshift(user);
    }
}
function unlike(comment,user){
    let idx= comment.likes.indexOf(user);
    if(idx>-1){
        comment.likes.splice(idx,1);
    }
}

async function addLike(commentid,user){
        let comment = await Comment.findOne({_id:commentid});
            Like(comment,user);
            await comment.save();
}

async function removeLike(commentid,user){
    let comment = await Comment.findOne({_id:commentid});
        unlike(comment,user);
        await comment.save();
}

async function commentInfo(commentid){
    let comment = await Comment.findOne({_id:commentid}).populate("likes").populate("userId").populate({path:"comments",
populate: {
    path:"userId likes"
}});
    return comment;
}
async function checkLike1(comment,user){
    // console.log(tweet);
    let data = await Comment.findOne(comment._id);
    // console.log(data);

    // console.log(data.likes.indexOf(user));
        return data.likes.indexOf(user)!=-1;
}





module.exports = {
        removeLike,addLike,commentInfo,checkLike1
}


