const route= require("express").Router();
const query = require("../Controller/query");
const Userquery = require("../Controller/userQuery");





route.get("/",async (req,res)=>{
   
    if(req.user){
        let data = await query.alltweets();
        data.reverse();
        await Userquery.beforeTweets(data,req.user._id);
        // console.log(data);
        return res.render("explore",{tweets:data,
            userId:req.user._id,
            name:req.user.full_name});
    }else{
       return  res.redirect("/login");
    }
})
route.get("/all-tweets",async (req,res)=>{
    if(req.user){
        let data = await query.alltweets();
        
       return  res.send(data);
    }else{
        return res.redirect("/");

    }
})



module.exports= route;